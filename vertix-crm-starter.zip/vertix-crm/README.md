# Veltrix CRM

Install:
npm install

Run:
npm run dev
