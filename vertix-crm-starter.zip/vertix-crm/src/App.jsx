import { useState } from "react";

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);

  if (!loggedIn) {
    return (
      <div style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"#f1f5f9"}}>
        <div style={{background:"white",padding:"40px",borderRadius:"16px",width:"420px"}}>
          <h1>Veltrix CRM</h1>
          <p>Enterprise Growth Platform</p>
          <input placeholder="Email" style={{width:"100%",padding:"12px",marginTop:"12px"}} />
          <input type="password" placeholder="Password" style={{width:"100%",padding:"12px",marginTop:"12px"}} />
          <button onClick={() => setLoggedIn(true)} style={{width:"100%",padding:"12px",marginTop:"12px"}}>
            Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{padding:"32px"}}>
      <h1>Veltrix CRM Dashboard</h1>
      <p>Phase 1 preview running.</p>
    </div>
  );
}